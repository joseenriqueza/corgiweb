import pandas


def get_pandas_version():
    return pandas.__version__
